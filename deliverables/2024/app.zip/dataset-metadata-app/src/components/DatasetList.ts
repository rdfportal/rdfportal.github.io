import React, { useEffect, useState } from 'react';
import yaml from 'js-yaml';

const DatasetList: React.FC = () => {
    const [datasets, setDatasets] = useState<any[]>([]);

    useEffect(() => {
        const fetchMetadata = async () => {
            const response = await fetch('/config/metadata.yaml');
            const text = await response.text();
            const data = yaml.load(text);
            setDatasets(data);
        };

        fetchMetadata();
    }, []);

    return (
        <div>
            <h1>Dataset List</h1>
            <ul>
                {datasets.map((dataset, index) => (
                    <li key={index}>
                        <h2>{dataset.title}</h2>
                        <p>{dataset.description}</p>
                        <p>Provider: {dataset.provider}</p>
                        <p>Version: {dataset.version}</p>
                        <p>Issued: {dataset.issued}</p>
                        <p>Creators:</p>
                        <ul>
                            {dataset.creators.map((creator: any, idx: number) => (
                                <li key={idx}>{creator.name} ({creator.affiliation})</li>
                            ))}
                        </ul>
                        <p>License: {dataset.licenses.join(', ')}</p>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default DatasetList;