import { DatasetList } from './components/DatasetList';

async function fetchMetadata() {
    const response = await fetch('/config/metadata.yaml');
    const text = await response.text();
    return parseYAML(text);
}

function parseYAML(yamlText: string) {
    // YAMLパーサーを使用してYAMLをオブジェクトに変換
    return YAML.parse(yamlText);
}

async function displayDatasets() {
    const metadata = await fetchMetadata();
    const datasetListElement = document.getElementById('dataset-list');

    if (datasetListElement && metadata) {
        const datasets = metadata.datasets; // metadata.yamlからデータセットのリストを取得
        datasets.forEach(dataset => {
            const datasetItem = document.createElement('div');
            datasetItem.innerHTML = `<h3>${dataset.title}</h3><p>${dataset.description}</p>`;
            datasetListElement.appendChild(datasetItem);
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    displayDatasets();
});