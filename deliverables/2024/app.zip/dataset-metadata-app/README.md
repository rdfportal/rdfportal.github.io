# Dataset Metadata Application

## Overview
The Dataset Metadata Application is designed to display a list of datasets along with their metadata. It retrieves metadata from a YAML configuration file and presents it in a user-friendly format.

## Project Structure
```
dataset-metadata-app
├── src
│   ├── index.html        # Main HTML page for the application
│   ├── app.ts           # Entry point of the application
│   └── components
│       └── DatasetList.ts # Component to display the dataset list
├── config
│   └── metadata.yaml     # YAML file containing dataset metadata
├── package.json          # npm configuration file
├── tsconfig.json         # TypeScript configuration file
└── README.md             # Project documentation
```

## Installation
To install the necessary dependencies, run the following command in the project root directory:

```
npm install
```

## Usage
To start the application, use the following command:

```
npm start
```

Open your web browser and navigate to `http://localhost:3000` to view the application.

## Metadata
The application retrieves dataset metadata from the `config/metadata.yaml` file. Ensure that this file is properly formatted and contains all necessary information about the datasets.

## Contributing
Contributions are welcome! Please feel free to submit a pull request or open an issue for any suggestions or improvements.

## License
This project is licensed under the Attribution 4.0 International (CC BY 4.0) license.